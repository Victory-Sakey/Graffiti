lightbox.option({
    resizeDuration: 200,
    wrapAround: true,
    disableScrolling: true,
  });

function openReply() {
    document.getElementById('subscribe-container').style.display = 'block' , 'flex'
}


  